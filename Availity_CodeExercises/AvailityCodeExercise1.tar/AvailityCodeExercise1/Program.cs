﻿using System;
using System.Text.RegularExpressions;

namespace AvailityHomework_Exercise1
{
    class Program
    {
        static void Main(string[] args)
        {
            var line = "You've gotta tell it to do a thing.";
            if (args.Length > 0) {
                try
                {
                    if (IsBalancedCode(System.IO.File.ReadAllText(args[0])))
                    {
                        line = "That looks like valid LISP code";
                    }
                    else
                    {
                        line = "Nope, sorry.  That doesn't look so good.";
                    }
                }
                catch
                {
                    line = "Something went wrong reading in the file";
                }
                finally
                {
                    //Nothing needs done here
                }
            }
            else {
                //Nothing needs done here
            }
            Console.WriteLine(line);
            Console.ReadLine();
        }


        static bool IsBalancedCode(string input)
        {
            //We can also check for properly balanced code in most languages using the three regular expressions for determining the "balancing" of parentheses, brackets, and braces
            var r = new Regex(@"((?>((?<c>) |[^()] +|)(?<-c>))*(?(c)(?!)))");
            return r.IsMatch(input);

        }
    }
}
